<?php
session_start();
 ?>
<!DOCTYPE html>
<html>
  <?php include 'C:\xampp\htdocs\site\body\header.html'; ?>
    <title></title>
  </head>
  <body class="w3-light-grey">

<div class="w3-container w3-top w3-black w3-large w3-padding" style="z-index:4">
  <button class="w3-btn w3-hide-large w3-padding-0 w3-hover-text-grey" onclick="w3_open();"><i class="fa fa-bars"></i>  Menu</button>

  <span class="w3-right"><?php echo 'Bienvenue,'.$_SESSION['login'];?></span>
</div>
<br>
<br>

<nav class="w3-sidenav w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidenav"><br>
  <div class="w3-container w3-row">
  <hr>
  <div class="w3-container">
    <h5>Pannel administration</h5>
  </div>
  <a href="#" class="w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
  <a href="#" class="w3-padding"><i class="fa fa-users fa-fw"></i>Utilisateurs</a>
  <a href="#" class="w3-padding"><i class="fa fa-calendar"></i> Plannings</a>
  <a href="#" class="w3-padding"><i class="fa fa-power-off"></i> Déconnecter</a>
  <br><br>
</nav>
<center>

<div class="w3-container">
  <?php include 'C:\xampp\htdocs\site\fonctions\logBDD.php'; ?>
</div>
<center>


  <footer>
    <?php include 'C:\xampp\htdocs\site\body\footer.html'; ?>
  </footer>
</html>
