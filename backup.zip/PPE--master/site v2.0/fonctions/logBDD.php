<?php

// connexion au serveur
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

// test accès à BDD
if (!$connexion) {
  header("location: pages/404.html");
  exit;
}


//récupération de tous les enregistrements de la table _utilisateur

$resultat=mysql_query("SELECT * FROM _utilisateur",$connexion);


if ($resultat) {

  //récupération de chaque ligne
  ?>
  <link rel="stylesheet" type="text/css" href="C:\xampp\htdocs\site\css\main.css">
      <table>
       <thead>
        <tr>
          <th>id</th>
          <th>Poste</th>
          <th>Nom</th>
          <th>Prenom</th>
          <th>Mail</th>
          <th>Groupe id</th>
        </tr>
      </thead>

  <?php
  while ($utilisateur = mysql_fetch_array($resultat)) {

    echo "<td><strong>".$utilisateur["uti_id"]."</strong></td>";
    echo "<td><strong>".$utilisateur["uti_prenom"]."</strong></td>";
    echo "<td><strong>".$utilisateur["uti_nom"]."</strong></td>";
    echo "<td><strong>".$utilisateur["uti_poste"]."</strong></td>";
    echo "<td><strong>".$utilisateur["uti_email"]."</strong></td>";
    echo "<td><strong>".$utilisateur["grp_id"]."</strong></td></tr>";

    ?>

  </table>


<?php
}
 }else {
    echo "erreurs dans l'éxécution de la requetes</br>";
    echo "le message d'erreurs est : ". mysql_error($connexion);
  }

 ?>
