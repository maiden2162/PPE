<?php

// connexion au serveur
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

// test accès à BDD
if (!$connexion) {
  header("location: pages/404.html");
  exit;
}

//récupération de tous les enregistrements de la table _utilisateur
$resultat=mysql_query("SELECT * FROM _utilisateur",$connexion);
if ($resultat) {
  //récupération de chaque ligne
  while ($utilisateur = mysql_fetch_array($resultat)) {
  ?>
    <table>
     <thead>
      <tr>
        <th>id</th>
        <th>Poste</th>
        <th>Nom</th>
        <th>Prenom</th>
        <th>Mail</th>
        <th>Groupe id</th>
      </tr>
    </thead>

    <td><strong><?php echo $utilisateur["uti_id"] ?></strong></td>
    <td> <?php echo $utilisateur["uti_nom"] ?></td>
    <td><?php echo $utilisateur["uti_prenom"] ?></td>
    <td><?php echo $utilisateur["uti_email"] ?></td>
    <td><?php echo $utilisateur["grp_id"] ?></td>
    </tbody>
  </table>
<?php
}
  }else {
    echo "erreurs dans l'éxécution de la requetes</br>";
    echo "le message d'erreurs est : ". mysql_error($connexion);
  }

 ?>
