<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.css">
        <link rel="stylesheet" href="css/custom-styles.css">
        <link rel="stylesheet" href="css/font-awesome.css">
        <link rel="stylesheet" href="css/component.css">
        <link rel="stylesheet" href="css/font-awesome-ie7.css">


        <script src="js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->

        <!-- This code is taken from http://twitter.github.com/bootstrap/examples/hero.html -->

        <!-- Site header starts here -->




             <!-- main content starts here -->

            <div class="container b-radius-top">

                <div class="site-header">


                     <!-- Site Name starts here -->

                    <div class="site-name">
                        <h1>Filelec</h1>
                    </div>

                    <!-- Site Name ends -->

                     <!-- Menu starts here -->
                    <div class="menu">
                        <div class="navbar">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                               <i class="fw-icon-th-list"></i>
                            </a>
                            <div class="nav-collapse collapse">
                                <ul class="nav">
                                    <li><a href="#">Home</a></li>
                                    <li><a href="pages/camera.php">Caméra</a></li>
                                    <li><a href="#">Alarme</a></li>
                                    <li><a href="#">Détecteurs</a></li>
                                    <li><a href="#">Digicode</a></li>
                                    <li><a data-toggle="modal" data-target="#myModal">Inscription</a></li>
                                    <li><a href="pages/login.php">Login</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                  <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

    <!-- Modal content-->
          <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <center><h4 class="modal-title">Inscription</h4></center>
          </div>
          <div class="modal-body">
            <form class="" action="index.html" method="post">
              <center>
              <table>
            <tr>
              <input type="text" name="nom"placeholder="Nom"><br>
            </tr>
            <tr>
              <input type="number" name="prenom"placeholder="Prenom"><br>
            </tr>
            <tr>
              <input type="text" name="adresse"placeholder="Prenom"><br>
            </tr>
            <tr>
              <input type="date" name="Date de naissance"placeholder="Prenom"><br>
            </tr>
            <tr>
              <input type="email" name="email"placeholder="mail@mail.fr"><br><br>
            </tr>
            <tr>
              <button class="w3-btn w3-round-xxlarge" type="submit" name="submit">Valider</button>
            </tr>
              </table>
            </center>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
        </div>
                    <!-- Menu ends -->
                </div>

                <!-- Banner starts here -->

                <div class="banner">
                    <div class="carousel slide" id="myCarousel">
                                    <!-- Carousel items -->
                        <div class="carousel-inner">
                            <div class="item">
                                <img src="img/banner-image.jpg" alt="">
                                <div class="carousel-caption">
                                  <h2>FILELEC</h2>
                                  <h1>"La sécurité avant tout"</h1>
                                  <a href="#myModal" role="button" class="btn" data-toggle="modal"> more info</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                 <!-- Banner ends here -->


                 <!-- Main content starts here -->


                    <!-- Featured slider starts here -->

                <div class="hiding">
                    <h1>Morbi interdum mollis </h1>
                    <h5>Vestibulum auctor dapibus nequ</h5>
                    <div class="carousel slide" id="myCarousel2">
                                    <!-- Carousel items -->
                        <div class="carousel-inner">
                            <div class="item active">
                                <img src="img/img1.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/img2.jpg" alt="">
                            </div>
                            <div class="item">
                                <img src="img/img3.jpg" alt="">
                            </div>
                        </div>
                        <a class="carousel-control left" href="#myCarousel2" data-slide="prev"><i class="fw-icon-chevron-left"></i></a>
                        <a class="carousel-control right" href="#myCarousel2" data-slide="next"><i class="fw-icon-chevron-right"></i></a>
                    </div>

                </div>
                   <!-- Featured slider ends here -->


                    <!-- Featured content starts here -->




                        <!-- Featured slider starts here -->
                    <div class="featured-slider">
                        <h1>Caméra</h1>
                        <div id="myCarousel1" class="carousel slide">

                            <div class="carousel-inner">
                               <div class="item active">
                                    <div class="row-fluid">
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img1.png" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Caméra</span><br><br>
                                                        <span>200 euros</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="http://www.sulforteseguranca.com.br/wp-content/uploads/2012/10/gprs-270x170.png" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Alarme</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="http://media.mt.com/dam/LabDiv/Campaigns/testing_labs_2014/graphics/instruments/table_thumb_electro_3.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Détecteurs</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                        <img src="img/dig.jpg" width="270" height="170" class="b-radius-top">
                                                          <div class="slider-content b-radius-bottom">
                                                            <span>Digicode</span>
                                                          </div>
                                                    </div>
                                                </div>


                                    </div><!--/row-fluid-->
                                </div>
                                <div class="item">
                                    <div class="row-fluid">

                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img1.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Tante etvulputa</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img2.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Phasellus pede</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img3.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Morbi interdum</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                        <img src="img/img4.jpg" class="b-radius-top">
                                                          <div class="slider-content b-radius-bottom">
                                                            <span>Suspendisse mauris</span>
                                                          </div>
                                                    </div>
                                                </div>


                                    </div><!--/row-fluid-->
                                </div>
                                <div class="item">
                                    <div class="row-fluid">

                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img1.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Tante etvulputa</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img2.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Phasellus pede</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                      <img src="img/img3.jpg" class="b-radius-top">
                                                      <div class="slider-content b-radius-bottom">
                                                        <span>Morbi interdum</span>
                                                      </div>
                                                    </div>
                                                </div>
                                                <div class="span3">
                                                    <div class="gallery">
                                                        <img src="img/img4.jpg" class="b-radius-top">
                                                          <div class="slider-content b-radius-bottom">
                                                            <span>Suspendisse mauris</span>
                                                          </div>
                                                    </div>
                                                </div>


                                    </div><!--/row-fluid-->
                                </div>

                            <!-- Carousel items -->
                            </div>
                            <a class="carousel-control left" href="#myCarousel1" data-slide="prev"><i class="fw-icon-chevron-left"></i></a>
                            <a class="carousel-control right" href="#myCarousel1" data-slide="next"><i class="fw-icon-chevron-right"></i></a>
                        </div>
                    </div>

                    <!-- Featured ends here -->
                    <!-- Featured accordion starts here -->


                    <!-- Featured accordion ends here -->

                <!-- Main content ends here -->

            </div>
            <div class="container bg-blue b-radius-bottom">
                <div class="site-footer">
                    <div class="row-fluid">
                        <div class="span4">
                            <div class="user-info">
                                <i class="fw-icon-twitter"></i>
                                <h1><a href="#">Axel Lejeune</a></h1>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="user-info">
                                <i class="fw-icon-twitter"></i>
                                <h1><a href="#">Mohamed Jen</a></h1>
                            </div>
                        </div>
                        <div class="span4">
                            <div class="user-info">
                                <i class="fw-icon-twitter"></i>
                                <h1><a href="#">Vincent Pinelli</a></h1>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

       <script src="js/jquery-1.9.1.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/masonry.pkgd.min.js"></script>
    <script src="js/imagesloaded.js"></script>
    <script src="js/classie.js"></script>
    <script src="js/AnimOnScroll.js"></script>

    <script>
      new AnimOnScroll( document.getElementById( 'grid' ), {
        minDuration : 0.4,
        maxDuration : 0.7,
        viewportFactor : 0.2
      } );
    </script>
<script>
$('#myCarousel').carousel({
    interval: 1800
});
</script>




   </body>
</html>
