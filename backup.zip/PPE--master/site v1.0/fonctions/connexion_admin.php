<?php
//connexion admin

session_start();
/* si l'utilisateur valide le formulaire on stock
dans des variables*/
if(isset($_POST['submit'])){
  $login=$_POST['login'];
  $password=$_POST['password'];

  if($login&&$password){//on compare entre le formulaire et la BDDintreanet
//---------------------------------------------------
//connexion a la BDDintreanet
//---------------------------------------------------
  $connexion = @mysql_connect('localhost','root','');
  mysql_select_db('bddintra');
//---------------------------------------------------
$query=mysql_query("SELECT * FROM admin WHERE login='$login' AND password='$password'");
//mysql_query permet d envoyer une requette sql à une BDD
$rows=mysql_num_rows($query);
//on parcourt la table
      if ($rows==1) {
        $_SESSION['login']=$login;
        header('location: pages/admin.php');
    }else echo "login ou password incorrect";
  }else echo "veuillez saisir tout les champs";
}
?>
