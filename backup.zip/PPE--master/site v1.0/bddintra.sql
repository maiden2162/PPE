#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------
DROP database IF EXISTS `bddintra`;
Create database bddintra;
use bddintra

#------------------------------------------------------------
# Table: CLIENT
#------------------------------------------------------------

CREATE TABLE CLIENT(
        id_cli      Int NOT NULL ,
        raison_cli  Varchar (45) ,
        adresse_cli Varchar (25) ,
        tel_cli     Char (10) ,
        PRIMARY KEY (id_cli )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: BON_LIVRAISON
#------------------------------------------------------------

CREATE TABLE BON_LIVRAISON(
        id_bonliv Int NOT NULL ,
        id_cli    Int ,
        PRIMARY KEY (id_bonliv )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: LOT_LIVRAISON
#------------------------------------------------------------

CREATE TABLE LOT_LIVRAISON(
        id_lot       Int NOT NULL ,
        quantite_lot Int ,
        datefab_lot  Date ,
        datedep_lot  Date ,
        dateliv_lot  Date ,
        id_bonliv    Int ,
        PRIMARY KEY (id_lot )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: CAMION
#------------------------------------------------------------

CREATE TABLE CAMION(
        id_ca     Int NOT NULL ,
        marque_ca Varchar (25) ,
        immat_ca  Char (7) ,
        PRIMARY KEY (id_ca )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: MATIERES_PREMIERES
#------------------------------------------------------------

CREATE TABLE MATIERES_PREMIERES(
        id_mat  Int NOT NULL ,
        nom_mat Varchar (25) ,
        PRIMARY KEY (id_mat )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: FOURNISSEURS
#------------------------------------------------------------

CREATE TABLE FOURNISSEURS(
        id_four      Int NOT NULL ,
        nom_four     Varchar (25) ,
        adresse_four Varchar (25) ,
        tel_four     Char (10) ,
        PRIMARY KEY (id_four )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: ORDRE_FABRICATION
#------------------------------------------------------------

CREATE TABLE ORDRE_FABRICATION(
        id_ord Int NOT NULL ,
        id_cli Int ,
        PRIMARY KEY (id_ord )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: LOT_LIVRAISONN
#------------------------------------------------------------

CREATE TABLE LOT_LIVRAISONN(
        id_lot       Int NOT NULL ,
        quantite_lot Int ,
        datefab_lot  Date ,
        datedep_lot  Date ,
        dateliv_lot  Date ,
        res_id       Int ,
        idd          Int ,
        PRIMARY KEY (id_lot )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Demande_livraison
#------------------------------------------------------------

CREATE TABLE Demande_livraison(
        idd                int (11) Auto_increment  NOT NULL ,
        quantite_livraison Int ,
        PRIMARY KEY (idd )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: prop_com
#------------------------------------------------------------

CREATE TABLE prop_com(
        Prop_num  int (11) Auto_increment  NOT NULL ,
        Prop_date Date ,
        Prop_text Varchar (25) ,
        id_cli    Int ,
        PRIMARY KEY (Prop_num )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Avis_cpta
#------------------------------------------------------------

CREATE TABLE Avis_cpta(
        Num_cpa   int (11) Auto_increment  NOT NULL ,
        avis_text Varchar (25) ,
        Prop_num  Int ,
        PRIMARY KEY (Num_cpa )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Note
#------------------------------------------------------------

CREATE TABLE Note(
        Note_num  int (11) Auto_increment  NOT NULL ,
        Note_text Varchar (25) ,
        Prop_num  Int ,
        PRIMARY KEY (Note_num )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Bon_commande
#------------------------------------------------------------

CREATE TABLE Bon_commande(
        BON_num       int (11) Auto_increment  NOT NULL ,
        BON__quantite Int ,
        BON_prix      Int ,
        BON_DATE      Date ,
        Prop_num      Int ,
        PRIMARY KEY (BON_num )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: avir_Dir
#------------------------------------------------------------

CREATE TABLE avir_Dir(
        davi_dir  int (11) Auto_increment  NOT NULL ,
        davi_text Varchar (25) ,
        Prop_num  Int ,
        PRIMARY KEY (davi_dir )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: avis_prod
#------------------------------------------------------------

CREATE TABLE avis_prod(
        pavi_num  int (11) Auto_increment  NOT NULL ,
        pavi_text Varchar (25) ,
        Prop_num  Int ,
        PRIMARY KEY (pavi_num )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: _UTILISATEUR
#------------------------------------------------------------

CREATE TABLE _UTILISATEUR(
        uti_id     Int NOT NULL ,
        uti_poste  Varchar (25) ,
        uti_nom    Varchar (25) ,
        uti_prenom Varchar (25) ,
        uti_email  Varchar (25) ,
        grp_id     Int ,
        PRIMARY KEY (uti_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: GROUPE_PRIVILEGE
#------------------------------------------------------------

CREATE TABLE GROUPE_PRIVILEGE(
        grp_id  Int NOT NULL ,
        grp_nom Varchar (25) ,
        PRIMARY KEY (grp_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: RESSOURCES
#------------------------------------------------------------

CREATE TABLE RESSOURCES(
        res_id   Int NOT NULL ,
        res_nom  Varchar (25) ,
        res_type Varchar (25) ,
        res_date Date ,
        PRIMARY KEY (res_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: membre
#------------------------------------------------------------

CREATE TABLE membre(
        id       Int NOT NULL ,
        login    Char (25) ,
        password Char (25) ,
        uti_id   Int NOT NULL ,
        PRIMARY KEY (id ,uti_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: admin
#------------------------------------------------------------

CREATE TABLE admin(
        id       Int NOT NULL ,
        login    Char (25) ,
        password Char (25) ,
        uti_id   Int NOT NULL ,
        PRIMARY KEY (id ,uti_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Transporter
#------------------------------------------------------------

CREATE TABLE Transporter(
        id_ca                Int NOT NULL ,
        id_lot               Int NOT NULL ,
        id_lot_LOT_LIVRAISON Int NOT NULL ,
        PRIMARY KEY (id_ca ,id_lot ,id_lot_LOT_LIVRAISON )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: fournir
#------------------------------------------------------------

CREATE TABLE fournir(
        id_four Int NOT NULL ,
        id_mat  Int NOT NULL ,
        PRIMARY KEY (id_four ,id_mat )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: composer
#------------------------------------------------------------

CREATE TABLE composer(
        id_mat Int NOT NULL ,
        res_id Int NOT NULL ,
        PRIMARY KEY (id_mat ,res_id )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: donner_lieu
#------------------------------------------------------------

CREATE TABLE donner_lieu(
        idd    Int NOT NULL ,
        id_ord Int NOT NULL ,
        PRIMARY KEY (idd ,id_ord )
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Accéder à
#------------------------------------------------------------

CREATE TABLE Acceder_a(
        res_id Int NOT NULL ,
        grp_id Int NOT NULL ,
        PRIMARY KEY (res_id ,grp_id )
)ENGINE=InnoDB;

ALTER TABLE BON_LIVRAISON ADD CONSTRAINT FK_BON_LIVRAISON_id_cli FOREIGN KEY (id_cli) REFERENCES CLIENT(id_cli);
ALTER TABLE LOT_LIVRAISON ADD CONSTRAINT FK_LOT_LIVRAISON_id_bonliv FOREIGN KEY (id_bonliv) REFERENCES BON_LIVRAISON(id_bonliv);
ALTER TABLE ORDRE_FABRICATION ADD CONSTRAINT FK_ORDRE_FABRICATION_id_cli FOREIGN KEY (id_cli) REFERENCES CLIENT(id_cli);
ALTER TABLE LOT_LIVRAISONN ADD CONSTRAINT FK_LOT_LIVRAISONN_res_id FOREIGN KEY (res_id) REFERENCES RESSOURCES(res_id);
ALTER TABLE LOT_LIVRAISONN ADD CONSTRAINT FK_LOT_LIVRAISONN_idd FOREIGN KEY (idd) REFERENCES Demande_livraison(idd);
ALTER TABLE prop_com ADD CONSTRAINT FK_prop_com_id_cli FOREIGN KEY (id_cli) REFERENCES CLIENT(id_cli);
ALTER TABLE Avis_cpta ADD CONSTRAINT FK_Avis_cpta_Prop_num FOREIGN KEY (Prop_num) REFERENCES prop_com(Prop_num);
ALTER TABLE Note ADD CONSTRAINT FK_Note_Prop_num FOREIGN KEY (Prop_num) REFERENCES prop_com(Prop_num);
ALTER TABLE Bon_commande ADD CONSTRAINT FK_Bon_commande_Prop_num FOREIGN KEY (Prop_num) REFERENCES prop_com(Prop_num);
ALTER TABLE avir_Dir ADD CONSTRAINT FK_avir_Dir_Prop_num FOREIGN KEY (Prop_num) REFERENCES prop_com(Prop_num);
ALTER TABLE avis_prod ADD CONSTRAINT FK_avis_prod_Prop_num FOREIGN KEY (Prop_num) REFERENCES prop_com(Prop_num);
ALTER TABLE _UTILISATEUR ADD CONSTRAINT FK__UTILISATEUR_grp_id FOREIGN KEY (grp_id) REFERENCES GROUPE_PRIVILEGE(grp_id);
ALTER TABLE membre ADD CONSTRAINT FK_membre_uti_id FOREIGN KEY (uti_id) REFERENCES _UTILISATEUR(uti_id);
ALTER TABLE admin ADD CONSTRAINT FK_admin_uti_id FOREIGN KEY (uti_id) REFERENCES _UTILISATEUR(uti_id);
ALTER TABLE Transporter ADD CONSTRAINT FK_Transporter_id_ca FOREIGN KEY (id_ca) REFERENCES CAMION(id_ca);
ALTER TABLE Transporter ADD CONSTRAINT FK_Transporter_id_lot FOREIGN KEY (id_lot) REFERENCES LOT_LIVRAISON(id_lot);
ALTER TABLE Transporter ADD CONSTRAINT FK_Transporter_id_lot_LOT_LIVRAISON FOREIGN KEY (id_lot_LOT_LIVRAISON) REFERENCES LOT_LIVRAISON(id_lot);
ALTER TABLE fournir ADD CONSTRAINT FK_fournir_id_four FOREIGN KEY (id_four) REFERENCES FOURNISSEURS(id_four);
ALTER TABLE fournir ADD CONSTRAINT FK_fournir_id_mat FOREIGN KEY (id_mat) REFERENCES MATIERES_PREMIERES(id_mat);
ALTER TABLE composer ADD CONSTRAINT FK_composer_id_mat FOREIGN KEY (id_mat) REFERENCES MATIERES_PREMIERES(id_mat);
ALTER TABLE composer ADD CONSTRAINT FK_composer_res_id FOREIGN KEY (res_id) REFERENCES RESSOURCES(res_id);
ALTER TABLE donner_lieu ADD CONSTRAINT FK_donner_lieu_idd FOREIGN KEY (idd) REFERENCES Demande_livraison(idd);
ALTER TABLE donner_lieu ADD CONSTRAINT FK_donner_lieu_id_ord FOREIGN KEY (id_ord) REFERENCES ORDRE_FABRICATION(id_ord);
ALTER TABLE Acceder_a ADD CONSTRAINT FK_Acceder_a_res_id FOREIGN KEY (res_id) REFERENCES RESSOURCES(res_id);
ALTER TABLE Acceder_a ADD CONSTRAINT FK_Acceder_a_grp_id FOREIGN KEY (grp_id) REFERENCES GROUPE_PRIVILEGE(grp_id);
