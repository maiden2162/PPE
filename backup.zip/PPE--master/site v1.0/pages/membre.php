<?php
session_start();
echo "salut";
 ?>
