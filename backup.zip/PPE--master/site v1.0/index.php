<!DOCTYPE html>
<html>
  <?php
  include 'body/header.html';
  include 'fonctions/redir_ind_vers_log.php';
  ?>
  <body>
    <div id="connexion">
      <form action="index.php" method="POST">
        <ul>
          <tr>
            <input type="submit" name="admin" value="admin"><br><br>
          </tr>
          <tr>
            <input type="submit" name="membre" value="membre"><br><br>
          </tr>
        </ul>
      </form>
    </div>
  </body>
</html>
