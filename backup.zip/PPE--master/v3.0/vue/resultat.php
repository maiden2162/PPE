<!-resultat tableau utilisateur->
<?php
include '../fonctions/supprimer_user.php';
 ?>
<div id="utilisateur">
<h1>Utilisateurs</h1>
      <table>
       <thead>
        <tr>
          <th><center>id</center></th>
          <th><center>Poste</center></th>
          <th><center>Nom</center></th>
          <th><center>Prenom</center></th>
          <th><center>Mail</center></th>
          <th><center>Groupe id</center></th>
          <th><center>Modifier</center></th>
          <th><center>Supprimer</center></th>
        </tr>
      </thead>
  <?php
  while ($utilisateur = mysql_fetch_array($resultat)): ?>
  <tr>
    <td><center><strong><?=$utilisateur["uti_id"]?></strong></center></td>
    <td><center><strong><?=$utilisateur["uti_poste"]?></strong></center></td>
    <td><center><strong><?=$utilisateur["uti_nom"]?></strong></center></td>
    <td><center><strong><?=$utilisateur["uti_prenom"]?></strong></center></td>
    <td><center><strong><?=$utilisateur["uti_email"]?></strong></center></td>
    <td><center><strong><?=$utilisateur["grp_id"]?></strong></center></td>
    <?="<td><center>".'<a href="../fonctions/modifier_user.php?uti_id='.$utilisateur['uti_id'].'" class="fa fa-pencil-square"></a>'."</center></td>";?>
    <?="<td><center>".'<a href="../fonctions/supprimer_user.php?uti_id='.$utilisateur['uti_id'].'" class="fa fa-window-close"></a>'."</center></td>";?>
  </tr>
<?php  endwhile ?>


  </table>

  </div>
