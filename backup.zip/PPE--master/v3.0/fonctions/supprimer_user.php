<?php
if (isset($_GET['uti_id'])) {
  $_SESSION['url']=$_SERVER['REQUEST_URI'];
  $_SESSION['uti_id'] = $_GET['uti_id'];
  $id=$_GET['uti_id'];

  $connexion = @mysql_connect('localhost','root','');
  mysql_select_db('bddintra');
  $query=mysql_query("DELETE  FROM _utilisateur WHERE uti_id = '$id'");
  header("location: ../pages/admin.php");
}
?>
