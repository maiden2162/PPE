<?php if (isset($_POST['admin'])) {
  header('location: ./pages/loginadmin.php');
}
//petit script qui dit si on clique sur admin rediriger vers login.php
?>
<?php if (isset($_POST['membre'])) {
  header('location: ./pages/loginmembre.php');
}
//petit script qui dit si on clique sur admin, rediriger vers membre.php
?>
