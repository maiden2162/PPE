<?php
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

if (isset($_POST['submit'])) {
  $id=$_POST["id"];
  $poste=$_POST["poste"];
  $nom=$_POST["nom"];
  $prenom=$_POST["prenom"];
  $email=$_POST["email"];
  $grp_id=$_POST["grp_id"];

  if ($id&&$poste&&$nom&&$prenom&&$email&&$grp_id) {
    $query = " INSERT INTO _utilisateur(uti_id,uti_poste,uti_nom,uti_prenom,uti_email,grp_id)
                    VALUES($id,'$poste','$nom','$prenom','$email',$grp_id )";

    mysql_query($query);
    mysql_close();
    header("location: ../pages/admin.php");
  }else{
      echo "Veuillez saisir tout les champs";
  }

}


 ?>
