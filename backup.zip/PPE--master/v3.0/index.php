<!DOCTYPE html>
<html>
  <?php
  include './body/header.php';
  include 'fonctions/redir_ind_vers_log.php';
  ?>
  <body>
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <div id="connexion">
      <form action="index.php" method="POST">
        <ul>
          <tr>
            <input type="submit" name="admin" value="admin"><br><br>
          </tr>
          <tr>
            <input type="submit" name="membre" value="connexion"><br><br>
          </tr>
        </ul>
      </form>
    </div>
  </body>
</html>
