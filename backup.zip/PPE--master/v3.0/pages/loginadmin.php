<!DOCTYPE html>
<html>
  <?php
  include '../body/header.php';
  ?>
  <body>
    <div id="connexion">
      <h1>admin</h1>
      <form action="loginadmin.php" method="POST">
        <ul>
          <tr>
            <input placeholder="login" type="text" name="login" ><br>
          </tr>
          <tr>
            <input placeholder="password" type="password" name="password" ><br><br>
          </tr>
          <tr>
            <input type="submit" name="submit" value="Se connecter"><br><br>
            <?php include ('../fonctions/connexion_admin.php'); ?>
          </tr>
        </ul>
      </form>
    </div>
  </body>
</html>
