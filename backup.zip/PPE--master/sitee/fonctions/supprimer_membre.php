<?php
if (isset($_GET['id'])) {
  $_SESSION['url']=$_SERVER['REQUEST_URI'];
  $_SESSION['id'] = $_GET['id'];
  $id=$_GET['id'];

  $connexion = @mysql_connect('localhost','root','');
  mysql_select_db('bddintra');
  $query=mysql_query("DELETE  FROM membre WHERE id = '$id'");
  header("location: ../pages/admin.php");
}
?>
