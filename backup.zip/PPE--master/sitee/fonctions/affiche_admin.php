<?php

include '../body/header.php';

// connexion au serveur
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

// test accès à BDD
if (!$connexion) {
  header("Location:../pages/erreur.php");
  exit;
}
//récupération de tous les enregistrements de la table _admin
$resultat=mysql_query("SELECT * FROM admin",$connexion);


if ($resultat) {
  //récupération de chaque ligne
include '../vue/tableau_admin.php';
 }else {
    header("Location:../pages/erreur.php");
  }

 ?>
