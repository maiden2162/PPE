<?php

include '../body/header.php';

// connexion au serveur
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

// test accès à BDD
if (!$connexion) {
  header("Location:../pages/erreur.php");
  exit;
}
//récupération de tous les enregistrements de la table _utilisateur
$resultat=mysql_query("SELECT * FROM _utilisateur",$connexion);


if ($resultat) {
  //récupération de chaque ligne
include '../vue/resultat.php';
 }else {
    header("Location:../pages/erreur.php");
  }

 ?>
