<?php
$connexion = @mysql_connect('localhost','root','');
mysql_select_db('bddintra');

if (isset($_POST['submit'])) {
  $id=$_POST["id"];
  $login=$_POST["login"];
  $password=$_POST["password"];



  if ($id&&$login&&$password) {
    $query = " INSERT INTO admin(id,login,password)
                    VALUES($id,'$login','$password')";

    mysql_query($query);
    mysql_close();
    header("location: ../pages/admin_liste.php");
  }else{
      echo "Veuillez saisir tout les champs";
  }

}


 ?>
