<script type="text/javascript">
if ( window.addEventListener ) {
var kkeys = [], konami = "113";
window.addEventListener("keydown", function(e){
kkeys.push( e.keyCode );
if ( kkeys.toString().indexOf( konami ) >= 0 ) {
document.location = "./pages/loginadmin.php";
}
}, true);
}

</script>
