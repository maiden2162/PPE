
<html>
  <?php
  include '../body/header.php';
  ?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Filelec</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="../assets/css/main.css" />
		<noscript><link rel="stylesheet" href="../assets/css/noscript.css"/></noscript>
	</head>
	<body>
			<div id="wrapper">
					<header id="header">
						<div class="logo">
							<span class="icon fa fa-laptop"></span>
						</div>
						<div class="content">
							<div class="inner">
                <form action="loginadmin.php" method="POST">
                  <h3>Admin</h3>
                    <ul>
                      <tr>
                        <input placeholder="login" type="text" name="login" ><br>
                      </tr>
                      <tr>
                    <input placeholder="password" type="password" name="password" ><br><br>
                    </tr>
                    <tr>
                    <input type="submit" name="submit" value="Se connecter"><br><br>
                    <?php include ('../fonctions/connexion_admin.php'); ?>
							</div>
						</div>
					</header>
					<footer id="footer">
						<p class="copyright">&copy; Axel leJeune,Vincent Pinelli,mohamed Jen.</p>
					</footer>
			</div>

			<div id="bg"></div>

			<script src="../assets/js/jquery.min.js"></script>
			<script src="../assets/js/skel.min.js"></script>
			<script src="../assets/js/util.js"></script>
			<script src="../assets/js/main.js"></script>


	</body>
</html>
