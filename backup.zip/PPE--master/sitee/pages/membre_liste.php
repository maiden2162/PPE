<?php
//ouvrir une session
session_start();
 ?>
<!DOCTYPE ht0ml>
<html>
  <?php include '../body/header.php'; ?>
    <title></title>
  </head>
  <body class="w3-light-grey">
<div class="w3-container w3-top w3-black w3-large w3-padding" style="z-index:4">
  <button class="w3-btn w3-hide-large w3-padding-0 w3-hover-text-grey" onclick="w3_open();"><i class="fa fa-bars"></i> Menu</button>
  <span class="w3-right"><?php echo 'Bienvenue, '.$_SESSION['login'];?></span>
  <a href="../vue/ajouter_mbr.php" class="w3-padding"><i></i>Ajouter membre</a>
</div>
<br>
<br>
<nav class="w3-sidenav w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidenav"><br>
  <div class="w3-container w3-row">
  <hr>
  <div class="w3-container">
    <h5>Panel administration</h5>
  </div>
  <a href="#" class="w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
  <a href="../pages/admin.php" class="w3-padding"><i class="fa fa-users fa-fw"></i> liste Utilisateurs</a>
  <a href="../pages/admin_liste.php" class="w3-padding"><i class="fa fa-users fa-fw"></i> liste admin</a>
  <a href="../pages/membre_liste.php" class="w3-padding"><i class="fa fa-users fa-fw"></i> liste membre</a>
  <a href="#" class="w3-padding"><i class="fa fa-calendar"></i> Plannings</a>
  <a href="../pages/deconnexion.php" class="w3-padding"><i class="fa fa-power-off"></i> Déconnecter</a>
  <br><br>
</nav>
<center>

<div class="w3-container">
  <?php include '../fonctions/affiche_membre.php'; ?>
</div>
<div class="container">
  <h2>Modal Example</h2>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!--Contenu du modal-->
     <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal">&times;</button>
         <h4 class="modal-title">Modal Header</h4>
       </div>
       <div class="modal-body">
         <form class="" action="ajouter_uti.php" method="post">
         <table>
           <ul><br><br><br>
             <tr>
               <input type="number" name="id" placeholder="id"><br>
             </tr>
             <tr>
               <input type="text" name="poste"placeholder="poste"><br>
             </tr>
             <tr>
               <input type="text" name="nom"placeholder="Nom"><br>
             </tr>
             <tr>
               <input type="text" name="prenom"placeholder="Prenom"><br>
             </tr>
             <tr>
               <input type="email" name="email"placeholder="mail@.fr"><br><br>
             </tr>
             <tr>
               <select class="" name="grp_id">
                 <option value=1>admin</option>
                 <option value=2>membre</option>
               </select><br><br>
             </tr>
             <tr>
               <button class="w3-btn w3-round-xxlarge" type="submit" name="submit">Valider</button>
               <?php include '../fonctions/phpajouter_utilisateurs.php'; ?>
             </tr>
       </div>
       <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       </div>
     </div>
<center>
  <footer>
    <?php include '../body/footer.php'; ?>
  </footer>
</html>
